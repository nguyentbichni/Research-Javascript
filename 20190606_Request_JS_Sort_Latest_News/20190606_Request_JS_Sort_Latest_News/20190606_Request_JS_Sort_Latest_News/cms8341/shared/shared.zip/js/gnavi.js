//gnaviListArray
var gnaviListArray = [
	[
		['/bosaikyukyu/bosai/index.html', '防災'],
		['/bosaikyukyu/saigai/index.html', '災害'],
		['/bosaikyukyu/kyukyu/index.html', '消防・救急'],
		['/bosaikyukyu/shobodan/index.html', '消防団'],
		['/bosaikyukyu/kokuminhogo/index.html', '国民保護'],
		['/bosaikyukyu/bohan/index.html', '防犯・交通安全'],
		['/bosaikyukyu/kinkyusaigai.html', '緊急時災害情報']
	],
	[
		['/kurashi/todokede/index.html', '届出・証明'],
		['/kurashi/shize/index.html', '市税'],
		['/kurashi/kenkohoken/index.html', '国民健康保険'],
		['/kurashi/nenkin/index.html', '年金'],
		['/kurashi/risaikuru/index.html', 'ごみ・リサイクル'],
		['/kurashi/kankyoese/index.html', '環境・衛生・動植物'],
		['/kurashi/jogesuido/index.html', '上下水道'],
		['/kurashi/jutaku/index.html', '住宅・建築'],
		['/kurashi/doro/index.html', '道路・交通'],
		['/kurashi/gyoseku/index.html', '行政区・市民活動・協働'],
		['/kurashi/kakushusodan/index.html', '各種相談・消費生活'],
		['/kurashi/gaikokujin/index.html', '外国人向け情報'],
		['/kokuminhoken/kurashi/kokikoresha.html', '後期高齢者医療保健'],
		['/shiminkatsudo/kurashi/kasoba/index.html', '火葬場・斎場']
	],
	[
		['/kosodate/ninshin/index.html', '妊娠・出産'],
		['/kosodate/kosadatehoiku/index.html', '子育て・保育'],
		['/kosodate/kyoiku/index.html', '教育・学校・学童保育'],
		['/kosodate/seshonenikuse/index.html', '青少年育成'],
		['/kosodate/shogaigakushu/index.html', '生涯学習'],
		['/kosodate/sports/index.html', 'スポーツ'],
		['/kosodate/bunka/index.html', '文化・歴史'],
		['/kosodate/bijutsukan/index.html', '美術館・博物館'],
		['/toshokan/kosodate/library.html', '図書館']
	],
	[
		['/kenko/kenkoiryo/index.html', '健康・医療'],
		['/kenko/nsedonitsuite/index.html', '介護保険'],
		['/kenko/koreshafukushi/index.html', '高齢者福祉'],
		['/kenko/shogaifukushi/index.html', '障がい者福祉'],
		['/kenko/fukushiippan/index.html', '福祉一般']
	],
	[
		['/sangyo/kanko/index.html', '観光'],
		['/sangyo/recreation/index.html', 'レジャー・レクリエーション'],
		['/sangyo/event/index.html', 'イベント'],
		['/sangyo/shushoku/index.html', '就職・労働'],
		['/sangyo/sangyoshinko/index.html', '産業振興'],
		['/sangyo/noringyo/index.html', '農林業'],
		['/sangyo/shokogyo/index.html', '商工業'],
		['/sangyo/kigyo/index.html', '起業・中小企業支援']
	],
	[
		['/shisejoho/shinogaiyo/index.html', '市の概要'],
		['/shisejoho/soshiki/index.html', '組織'],
		['/shisejoho/jinji/index.html', '人事・職員採用'],
		['/shisejoho/kocho/index.html', '広聴・広報'],
		['/shisejoho/shisaku/index.html', '施策・計画'],
		['/shisejoho/nyusatsu/index.html', '入札・契約'],
		['/shisejoho/shitekanrisha/index.html', '指定管理者制度'],
		['/shisejoho/zaise/index.html', '財政'],
		['/shisejoho/johokokaihogo/index.html', '情報公開・個人情報保護'],
		['/shisejoho/fuzokukikan/index.html', '付属機関・審議会'],
		['/shisejoho/kansa/index.html', '監査・行政不服'],
		['/shisejoho/senkyo/index.html', '選挙'],
		['/shisejoho/shigikai/index.html', '市議会']
	]
];