/*
 * アクセスランキングCSVを読み込み、ランキングを表示する(ダミーファイル)
 * $Rev:  $
 * $Date:  $
 * $Author:  $
 */
var fnc_acc_rank = function(objId,rank_id) {
	return true;
}

fnc_acc_rank.prototype = {
	/**
	 * ダミー関数
	 */
	LoadData : function() {
		return true;
	}
}
